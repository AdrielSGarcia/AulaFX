package model;

import javafx.beans.property.*;

/**
 * Classe modelo para representar um Produto, utilizando propriedades JavaFX.
 * Isso permite o data binding (vinculação de dados) com componentes da interface
 * gráfica, como TableView, e facilita a atualização da UI quando os dados
 * mudam.
 */
public class Produto {

    // Atributos baseados em propriedades JavaFX
    private final IntegerProperty id;
    private final StringProperty descricao;
    private final DoubleProperty preco;
    private final IntegerProperty quantidadeEstoque;

    /**
     * Construtor padrão.
     * Inicializa todas as propriedades JavaFX.
     */
    public Produto() {
        this.id = new SimpleIntegerProperty();
        this.descricao = new SimpleStringProperty();
        this.preco = new SimpleDoubleProperty();
        this.quantidadeEstoque = new SimpleIntegerProperty();
    }

    /**
     * Construtor parametrizado.
     * Útil para criar novas instâncias de Produto com dados iniciais
     * (por exemplo, ao adicionar um novo produto antes de salvar no BD).
     * O 'id' geralmente não é incluído aqui, pois é gerado pelo banco de dados (Auto Increment).
     *
     * @param descricao Descrição ou nome do produto.
     * @param preco Preço de venda do produto.
     * @param quantidadeEstoque Quantidade atual em estoque.
     */
    public Produto(String descricao, double preco, int quantidadeEstoque) {
        this(); // Chama o construtor padrão para inicializar as propriedades
        this.descricao.set(descricao);
        this.preco.set(preco);
        this.quantidadeEstoque.set(quantidadeEstoque);
    }

    // --- Getters, Setters e Métodos de Propriedade (Padrão JavaFX Bean) ---

    // ID
    public int getId() {
        return id.get();
    }

    public void setId(int id) {
        this.id.set(id);
    }

    public IntegerProperty idProperty() {
        return id;
    }

    // Descrição
    public String getDescricao() {
        return descricao.get();
    }

    public void setDescricao(String descricao) {
        this.descricao.set(descricao);
    }

    public StringProperty descricaoProperty() {
        return descricao;
    }

    // Preço
    public double getPreco() {
        return preco.get();
    }

    public void setPreco(double preco) {
        this.preco.set(preco);
    }

    public DoubleProperty precoProperty() {
        return preco;
    }

    // Quantidade em Estoque
    public int getQuantidadeEstoque() {
        return quantidadeEstoque.get();
    }

    public void setQuantidadeEstoque(int quantidadeEstoque) {
        this.quantidadeEstoque.set(quantidadeEstoque);
    }

    public IntegerProperty quantidadeEstoqueProperty() {
        return quantidadeEstoque;
    }
    
    /**
     * Retorna a descrição do produto.
     * Usado por padrão em componentes como ComboBox ou ListView ao exibir o objeto.
     */
    @Override
    public String toString() {
        return descricao.get();
    }
}